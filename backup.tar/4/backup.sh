#!/bin/bash
tar -czf backup.tar $1;
